var searchData=
[
  ['manage_1',['manage',['../namespacemanage.html',1,'']]]
];
